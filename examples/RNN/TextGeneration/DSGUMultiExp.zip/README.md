Use following algorithm to run program.

THEANO_FLAGS=floatX=float32,device=gpu0,nvcc.fastmath=True  python <myscript>.py